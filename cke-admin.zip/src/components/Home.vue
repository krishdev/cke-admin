<template>
	<h4>Home</h4>
</template>
<<script>
	export default{
		name:"Home",
		created:function() {
			this.$emit("nav-show",true,"Home");
		}
	}
</script>