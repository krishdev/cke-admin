<template>
	<v-content style="padding:0">
	 	<v-dialog v-model="dialog" max-width="900px">
	  		<v-card>
			    <v-card-title>
			      <span class="headline">Edit</span>
			    </v-card-title>
			    <v-card-text>
		      		<v-container grid-list-md>
			        <v-layout wrap>
						<v-flex xs12>
							<v-text-field v-model="editedTimeline.description" 
							  :error-messages="descriptionErrors"                  
			                  label="Description"
			                  required
			                  @input="$v.editedTimeline.description.$touch()"
			                  @blur="$v.editedTimeline.description.$touch()">  
							></v-text-field>
						</v-flex>
						<v-flex xs12>
							<v-select
				                :items="['Bookish','Sports','General', 'Culturals']"
				                v-model="editedTimeline.activity"
				                :error-messages="activityErrors"
				                label="Activity"
				                item-value="text"
			              	></v-select>
						</v-flex>
						<v-flex xs12>
							<v-menu
				              lazy
				              :close-on-content-click="true"
				              v-model="menu"
				              transition="v-scale-transition"
				              offset-y
				            >
			              		<v-text-field
					                required
					                slot="activator"
					                label="Date"
					                v-model="formatedDate"
					                readonly
					                :error-messages="dateErrors"                  
				                    @input="$v.editedTimeline.date.$touch()"
				                    @blur="$v.editedTimeline.date.$touch()"
					              ></v-text-field>
						        <v-date-picker
	                       		  no-title
						          v-model="timePicker"
						          :date-format="date => new Date(date).toDateString()"
						          :formatted-value.sync="formatted"
						        ></v-date-picker>
				            </v-menu>
						</v-flex>
			        </v-layout>
		      	</v-container>
		    </v-card-text>
		    <v-card-actions>
		      <v-flex xs12>            
		        <v-alert :value="true" v-if="editSuccess" type="success">
		            The Timeline has been successfully updated.
		        </v-alert> 
		      </v-flex>
		      <v-spacer></v-spacer>
		      <v-btn color="blue darken-1" flat @click.native="dialog = !dialog">Cancel</v-btn>
		      <v-btn color="blue darken-1" flat @click.native="save(updateTimeline)">Save</v-btn>
		    </v-card-actions>
		  </v-card>
		</v-dialog>	

		<v-dialog v-model="dialogPress" max-width="900px">
	  		<v-card>
			    <v-card-title>
			      <span class="headline">Edit Press</span>
			    </v-card-title>
			    <v-card-text>
		      		<v-container grid-list-md>
			        <v-layout wrap>
						<v-flex xs12>
			            	<v-text-field
			                  v-model="editedPress.title"
			                  :error-messages="titleErrors"                  
			                  label="Title"
			                  required
			                  @input="$v.editedPress.title.$touch()"
			                  @blur="$v.editedPress.title.$touch()">                  
			                </v-text-field>
			            </v-flex>
			            <v-flex xs12>
			            	<v-text-field
			                  v-model="editedPress.url"
			                  :error-messages="urlErrors"                  
			                  label="Url"
			                  required
			                  @input="$v.editedPress.url.$touch()"
			                  @blur="$v.editedPress.url.$touch()">                  
			                </v-text-field>
			            </v-flex>	            
			            <v-flex xs12>
			            	<v-menu
				              lazy
				              :close-on-content-click="true"
				              v-model="menu2"
				              transition="v-scale-transition"
				              offset-y
				            >
			              		<v-text-field
					                required
					                slot="activator"
					                label="Date"
					                v-model="formatedPressDate"
					                readonly
					                :error-messages="datePressErrors"                  
				                    @input="$v.editedPress.date.$touch()"
				                    @blur="$v.editedPress.date.$touch()"
					              ></v-text-field>
						        <v-date-picker
	                       		  no-title
						          v-model="timePressPicker"
						          :date-format="date => new Date(date).toDateString()"
						          :formatted-value.sync="formatted"
						        ></v-date-picker>
				            </v-menu>
			            </v-flex>
			            <v-flex xs12>
			            	<v-alert :value="true" v-if="postSuccess" type="success">
						      The timeline has been successfully created.
						    </v-alert>
			            	<v-btn @click="createPress" color="green" style="margin-left:0;">Create Press<v-icon right dark>create</v-icon></v-btn>		
			            </v-flex>
			        </v-layout>
		      	</v-container>
		    </v-card-text>
		    <v-card-actions>
		      <v-flex xs12>            
		        <v-alert :value="true" v-if="editSuccess" type="success">
		            The Timeline has been successfully updated.
		        </v-alert> 
		      </v-flex>
		      <v-spacer></v-spacer>
		      <v-btn color="blue darken-1" flat @click.native="dialogPress = !dialogPress">Cancel</v-btn>
		      <v-btn color="blue darken-1" flat @click.native="savePress(updateTimeline)">Save</v-btn>
		    </v-card-actions>
		  </v-card>
		</v-dialog>	

		<v-data-table
		  :headers="headerTimeline"
	      :items="timeline"
	      hide-actions
	      class="elevation-1 rowTable timeline">
	      <template slot="items" slot-scope="article">
	        <td>{{ article.item.description }}</td>
	        <td class="text-xs-right">{{ article.item.date }}</td>
	        <td class="justify-center layout px-0">
	          <v-btn icon class="mx-0" @click="editItem(article.item)">
	            <v-icon color="teal">edit</v-icon>
	          </v-btn>
	          <!-- <v-btn icon class="mx-0" @click="deleteItem(article.item)">
	            <v-icon color="pink">delete</v-icon>
	          </v-btn> -->
	        </td>
	      </template>
	    </v-data-table>
	    <v-divider inset></v-divider>
	    <v-data-table
	      :headers="headerPress"
	      :items="press"
	      hide-actions
	      class="elevation-1 rowTable mt-5">
	      <template slot="items" slot-scope="article">
	        <td><a :href="article.item.url"> {{ article.item.title }} </a></td>
	        <td class="text-xs-right">{{ article.item.date }}</td>
	        <td class="justify-center layout px-0">
	          <v-btn icon class="mx-0" @click="editPressItem(article.item)">
	            <v-icon color="teal">edit</v-icon>
	          </v-btn>
	          <!-- <v-btn icon class="mx-0" @click="deleteItem(article.item)">
	            <v-icon color="pink">delete</v-icon>
	          </v-btn> -->
	        </td>
	      </template>
	    </v-data-table>
	</v-content>
</template>
<script>
	import { validationMixin } from 'vuelidate'
  	import { required, maxLength, email } from 'vuelidate/lib/validators'
	import { db } from '../main'
	export default {
		mixins: [validationMixin],    
		data: () =>({
			dialog: false,
			dialogPress: false,
			timeline:[],
			press:[],
			headerPress: [
				{
					text:"Press",
					sortable: false
				},
				{
					text:"",
					sortable: false
				},
				{
					text:" ",
					sortable: false,
					id:"dds"
				}
			],
			headerTimeline: [
				{
					text:"Timeline",
					sortable: false
				},
				{
					text:"",
					sortable: false
				},
				{
					text:" ",
					sortable: false,
					id:"d"
				}
			],
			editedTimeline:{
				id:"",
				description: "",
				activity:"",
				date:""
			},			
            editedPress: {
                id:"",
                date:"",
                url:"",
                title:""
            },
			timePicker: "",
			timePressPicker: "",
			formatted:"",
      		months:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
      		editSuccess: false,
      		menu: "",
      		menu2: ""
		}),
	  	filters: {
		    
		  format: function(date) {
		      var picker = new Date(date),
		          month,
		          finalFormat;
		    var self = this;
		    var months =["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
		            //debugger
		      if(!isNaN( picker.getTime() )){
		        month = months[picker.getMonth()]
		      } else {
		        picker = new Date();
		        month = months[picker.getMonth()]
		      }
		      finalFormat = month + " "+ picker.getUTCDate() + ", " + picker.getFullYear();
		      return finalFormat;
		    }
		},
		created () {
			var self = this;
	      	var ref = db.ref();
	      	ref.child("timeline").orderByChild("date").on("child_added", function(response){
	      		debugger;             
	      		self.timeline.push(response.val());          
	      	}) ;
	      	ref.child("press").orderByChild("date").on("child_added", function(response){
	      		debugger;             
	      		self.press.push(response.val());          
	      	}) 
		},
		computed: {
			titleErrors () {
		        const errors = []
		        if (!this.$v.editedPress.title.$dirty) return errors
		        !this.$v.editedPress.title.required && errors.push('Title is required.')
		        return errors
	      	},
	      	urlErrors () {
		        const errors = []
		        if (!this.$v.editedPress.url.$dirty) return errors
		        !this.$v.editedPress.url.required && errors.push('Url is required.')
		        return errors
	      	},
	      	datePressErrors () {
		        const errors = []
		        if (!this.$v.editedPress.date.$dirty) return errors
		        !this.$v.editedPress.date.required && errors.push('Date is required.')
		        return errors
	      	},
			descriptionErrors () {
		        const errors = []
		        if (!this.$v.editedTimeline.description.$dirty) return errors
		        !this.$v.editedTimeline.description.required && errors.push('Description is required.')
		        return errors
	      	},
	      	activityErrors () {
		        const errors = []
		        if (!this.$v.editedTimeline.activity.$dirty) return errors
		        !this.$v.editedTimeline.activity.required && errors.push('Activity is required.')
		        return errors
	      	},
	      	dateErrors () {
		        const errors = []
		        if (!this.$v.editedTimeline.date.$dirty) return errors
		        !this.$v.editedTimeline.date.required && errors.push('Date is required.')
		        return errors
	      	},
	      	formatedDate () {
	      		var formatedDate ;
				var self = this;
				var picker = new Date(this.editedTimeline.date),
				month;
			    //debugger
				if(!isNaN( picker.getTime() )){
				month = self.months[picker.getUTCMonth()]
				} else {
				picker = new Date();
				month = self.months[picker.getUTCMonth()]
				}
				formatedDate = month + " "+ picker.getUTCDate() + ", " + picker.getFullYear();
				return formatedDate; 
	      	},
	      	formatedPressDate () {
	      		var formatedDate ;
				var self = this;
				var picker = new Date(this.editedPress.date),
				month;
			    //debugger
				if(!isNaN( picker.getTime() )){
				month = self.months[picker.getUTCMonth()]
				} else {
				picker = new Date();
				month = self.months[picker.getUTCMonth()]
				}
				formatedDate = month + " "+ picker.getUTCDate() + ", " + picker.getFullYear();
				return formatedDate; 
	      	}
		},
		validations:{
	        editedTimeline:{
	            description:{
	                required
	            },
	            activity:{
	                required
	            },
	            date:{
	                required
	            }
	        },
	        editedPress: {
                date:"",
                url:"",
                title:""
            }
	    },
	 	watch:{
			"timePicker":function(newDate){
		  		var thisDate = new Date(newDate)
				  this.editedTimeline.date = thisDate.getTime();
				}
		},
		methods: {
			updateTimeline: function (editItem) {

			},
			editItem: function (editIt) {
				this.dialog = !this.dialog;
				this.editedTimeline = editIt;
			},
			editPressItem: function (editIt) {
				this.dialogPress = !this.dialogPress;
				this.editedPress = editIt;
			},
			savePress: function (){

			},
			save: function (){

			}
		}
	}
</script>
<style>
	@import "../assets/css/styles.css"
</style>